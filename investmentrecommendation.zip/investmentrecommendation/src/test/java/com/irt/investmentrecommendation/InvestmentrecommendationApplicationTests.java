package com.irt.investmentrecommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestmentrecommendationApplicationTests {

	@Test
	void contextLoads() {
	}

}
