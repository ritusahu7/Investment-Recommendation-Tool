$("#submit").click(function() {
	 if (!$('input[name="option"]').is(':checked')) {
		 $("#errors").show();
		 return false;
	 }else{
		 $(".formSubmit").submit();
	   }
	 });


$("#back").click(function() {
	  parent.history.back();
	 });
