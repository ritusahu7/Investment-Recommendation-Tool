package com.irt.investmentrecommendation.model;

public class RiskProfile {

	private int score;
	private String name;
	private String strategy;
	private int debtRecommendation;
	private int equityRecommendation;
	
	public RiskProfile() {
		
	}
	
	public void getRiskProfile(int score) {
	//	RiskProfile riskProfile = new RiskProfile();
		System.out.println("score is : "+ score);
		this.setScore(score);
		if(score>=16 && score<=22) {
			System.out.println("if block 1");
			this.setName("Conservative");
			this.setStrategy("Investment Strategy should be conservative, with entire amount invested in Debt funds");
			this.setDebtRecommendation(100);
			this.setEquityRecommendation(0);
		}else if(score>=23  &&  score<=32) {
			System.out.println("if block 2");
			this.setName("Moderately Conservative");
			this.setStrategy("Investment Strategy should be moderately conservative, with 80% of investment in debt funds and 20% in equity funds");
			this.setDebtRecommendation(80);
			this.setEquityRecommendation(20);
		}else if(score>=33  &&  score<=42) {
			System.out.println("if block 3");
			this.setName("Moderatee");
			this.setStrategy("Investment Strategy should be moderate, with 50% of investment in debt funds and 50% in equity funds");
			this.setDebtRecommendation(50);
			this.setEquityRecommendation(50);
		}else if(score>=43  &&  score<=52) {
			System.out.println("if block 4");
			this.setName("Moderately Aggressive");
			this.setStrategy("Investment Strategy should be moderately aggressive, with 20% of investment in debt funds and 80% in equity funds");
			this.setDebtRecommendation(20);
			this.setEquityRecommendation(80);
		}else if(score>=53  &&  score<=60) {
			System.out.println("if block 5");
			this.setName("Aggressive");
			this.setStrategy("Investment Strategy should be aggressive, with 0% of investment in debt funds and 100% in equity funds");
			this.setDebtRecommendation(0);
			this.setEquityRecommendation(100);
		}
		
		//return riskProfile;
	}
	
	public void setScore(int score) {
		this.score = score;
		
	}
	
	public int getScore() {
		return score;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStrategy() {
		return strategy;
	}
	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}
	public int getDebtRecommendation() {
		return debtRecommendation;
	}
	public void setDebtRecommendation(int debtRecommendation) {
		this.debtRecommendation = debtRecommendation;
	}
	public int getEquityRecommendation() {
		return equityRecommendation;
	}
	public void setEquityRecommendation(int equityRecommendation) {
		this.equityRecommendation = equityRecommendation;
	}

}
