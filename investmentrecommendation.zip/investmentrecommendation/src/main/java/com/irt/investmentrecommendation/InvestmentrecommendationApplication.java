package com.irt.investmentrecommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import com.irt.investmentrecommendation.model.InvestorDetail;
import com.irt.investmentrecommendation.model.RiskProfile;

@SpringBootApplication
public class InvestmentrecommendationApplication extends SpringBootServletInitializer{

	public static void main(String[] args) {
		SpringApplication.run(InvestmentrecommendationApplication.class, args);
	}

	@Bean
	public InvestorDetail getInvestorDetail() {
		return new InvestorDetail();
	}

	@Bean
	public RiskProfile getRiskProfile() {
		return new RiskProfile();
	}

}
