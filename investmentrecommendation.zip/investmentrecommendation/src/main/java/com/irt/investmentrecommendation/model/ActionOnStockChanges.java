package com.irt.investmentrecommendation.model;

import javax.validation.constraints.NotNull;

public class ActionOnStockChanges {

	@NotNull
	private String option;
	private int score;
	
	
	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
		setScore(option);
	}

	public int getScore() {
		return score;
	}
	
	public void setScore(String action) {
		if(action.equals("sellall")) {
			this.score = 3;
		}else if(action.equals("sellsome")) {
			this.score = 6;
		}else if(action.equals("donothing")) {
			this.score = 8;
		}else if(action.equals("buymore")) {
			this.score = 8;
		}else {
			this.score= 0;
		}
		
	}

}
