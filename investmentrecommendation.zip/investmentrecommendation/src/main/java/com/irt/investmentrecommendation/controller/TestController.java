package com.irt.investmentrecommendation.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.irt.investmentrecommendation.model.Greeting;

@Controller
public class TestController {

/*	
	@GetMapping("test")
	public String getTest(Model model) {
		return "test";
	} */
	
	@GetMapping("greeting")
    public String greeting (@ModelAttribute ("greeting") Greeting greeting, BindingResult result) {
       // model.put("message", "Hello Bryan");
        return "greeting";
    }
	
    @PostMapping("greeting")
    public String addRegistration(@ModelAttribute ("greeting")
                                              Greeting greeting,
                                  BindingResult result) {

        System.out.println("Registration: " + greeting.getName());

        return "redirect:greeting";
    }
	
	
    /*	@GetMapping("summarymessage")
    public String getHome (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "summarymessage";
    }
	
		@GetMapping("questionnaire")
    public String getQuestionnaire (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "questionnaire";
    }
	
	@GetMapping("second")
    public String getsecond (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "second";
    }
	
	@GetMapping("third")
    public String getThird (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "third";
    }
	
	@GetMapping("fourth")
    public String getFourth (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "fourth";
    }
	
	@GetMapping("fifth")
    public String getFifth (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "fifth";
    }
	
	@GetMapping("sixth")
    public String getSixth (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "sixth";
    }
	
	@GetMapping("result")
    public String getResult (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "result";
    }
	
	@GetMapping("summary")
    public String getSummary (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "summary";
    }
	
	@GetMapping("login")
    public String getLogin (Map<String, Object> model) {
        model.put("message", "Hello Bryan");
        return "login";
    } */
}
